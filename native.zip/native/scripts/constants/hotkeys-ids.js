export const kHotkeyToggle = 'sample_app_showhide';
export const kHotkeySecondScreen = 'sample_app_second_screen';
