export const kWindowNames =  {
  BACKGROUND: 'background',
  DESKTOP: 'desktop',
  SECOND: 'second',
  IN_GAME: 'in_game'
};
