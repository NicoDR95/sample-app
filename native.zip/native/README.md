## Important note

This is the native "pure" JS version of the sample app. Although the code is working, we highly recommend using the "ts" version, which uses the most up-to-date techniques and recommendations by us, like background controller, npm packages for def file, and more.

The TypeScript version can be found here: https://github.com/overwolf/sample-app/tree/master/ts.
