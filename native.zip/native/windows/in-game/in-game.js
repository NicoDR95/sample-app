import { InGameController } from './in-game-controller.js';

const inGameController = new InGameController();

inGameController.run();
