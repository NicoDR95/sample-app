import { DesktopView } from '../../windows/desktop/desktop-view.js';

export class DesktopController {
  constructor() {
    this.desktopView = new DesktopView();
  }

  run() {
  }
}
