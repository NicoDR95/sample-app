import { SampleAppView } from '../sample-app-view.js'

export class DesktopView extends SampleAppView {
  constructor() {
    super();
  }
}
