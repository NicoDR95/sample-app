import { DesktopController } from './desktop-controller.js';

const desktopController = new DesktopController();

desktopController.run();
