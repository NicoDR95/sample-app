import { SecondController } from './second-controller.js';

const secondController = new SecondController();

secondController.run();
